"""Shared agentenv baseline client implementation."""

from __future__ import annotations

import shlex
import threading
import time
import urllib.error
import urllib.request
from typing import Any

from .common import Target, http
from .persistent_shell import _AgentShell


class AgentEnvTarget(Target):
    name = "agentenv"

    def __init__(self, base: str, api_key: str, ttl: int):
        self.base = base.rstrip("/")
        self.key = api_key
        self.ttl = ttl
        self.headers = {"X-API-Key": api_key, "Authorization": f"Bearer {api_key}"}
        from e2b import Sandbox  # imported here so flash runs need no SDK

        self._Sandbox = Sandbox
        self._attached: dict[str, Any] = {}
        self._lock = threading.Lock()
        # One persistent bash per sandbox, opened lazily on the first exec
        # (see _shell_for). Keys match _attached so a single destroy tears
        # both down.
        self._shells: dict[str, _AgentShell] = {}

    def _connect(self, handle: str):
        """Attach an E2B client with the routing headers AgentENV needs.

        E2B SDK 2.20's class-level ``Sandbox.connect(id)`` omits the
        ``E2b-Sandbox-*`` headers that its create path adds.  AgentENV's
        reverse proxy consequently sees an ordinary control-plane request
        and returns 404 for every envd RPC.  Pass the headers explicitly so
        cold-created sandboxes use the same data-plane route as SDK-created
        sandboxes.
        """
        return self._Sandbox.connect(
            handle,
            api_url=self.base,
            sandbox_url=self.base,
            api_key=self.key,
            headers={
                "E2b-Sandbox-Id": handle,
                "E2b-Sandbox-Port": "49983",
            },
            request_timeout=20,
        )

    def create(self, lane: dict) -> str:
        _, body = http(
            f"{self.base}/sandboxes-cold",
            "POST",
            {"image": lane["image"], "timeout": self.ttl, "autoPause": False},
            self.headers,
        )
        if isinstance(body, list):
            body = body[0]
        sid = (body or {}).get("sandboxID") or (body or {}).get("sandboxId")
        if not sid:
            raise RuntimeError(f"create returned no id: {body!r}")
        return sid

    def attached(self, handle: str):
        """Return the E2B data-plane client for ``handle``, connecting lazily.

        Uses :meth:`_connect` (not the bare SDK connect) so cold-created
        sandboxes get the envd routing headers; the lock keeps concurrent
        lanes on one client per sandbox.
        """
        with self._lock:
            sbx = self._attached.get(handle)
            if sbx is None:
                sbx = self._connect(handle)
                self._attached[handle] = sbx
            return sbx

    def prepare(self, handle: str) -> None:
        sbx = self.attached(handle)

        # AgentENV can return before envd is ready to accept the first Start
        # RPC. Mirror the compatibility suite's settle/retry behavior here, but
        # keep it outside the measured exec timing.
        deadline = time.monotonic() + 30.0
        time.sleep(3.0)
        while True:
            try:
                try:
                    sbx.commands.run("true", timeout=5, request_timeout=20)
                except TypeError:  # older SDKs lack request_timeout
                    sbx.commands.run("true", timeout=5)
                return
            except Exception:
                if time.monotonic() >= deadline:
                    raise
                time.sleep(1.0)

    def execute(self, handle: str, argv: str | list[str], timeout_ms: int) -> int:
        return self.execute_full(handle, argv, timeout_ms)[0]

    def _shell_for(self, handle: str, *, timeout_ms: int) -> _AgentShell:
        """Return the persistent shell for ``handle``, opening it lazily.

        The shell is created on the FIRST exec of each sandbox (never in
        the untimed settle/prepare path), so -- exactly like flash-sandbox's
        ``POST /sandboxes/{id}/shell`` -- the first exec pays agent
        readiness + session establishment and the rest reuse it. That cost
        cancels in ``S_j = T_j(C)/T_j^iso`` because an isolated baseline
        pays it too.
        """
        with self._lock:
            shell = self._shells.get(handle)
            if shell is not None and shell._timeout_cleanup_confirmed:
                # Only the following command gets a new shell. The timed out
                # command is never resubmitted; filesystem changes remain.
                self._shells.pop(handle)
                shell = None
        if shell is not None:
            return shell
        shell = _AgentShell(self.attached(handle))
        shell.start(timeout=max(1.0, timeout_ms / 1000.0))
        with self._lock:
            existing = self._shells.get(handle)
            if existing is not None:
                # Another thread opened one first; close ours and use theirs.
                shell.close()
                return existing
            self._shells[handle] = shell
        return shell

    def close_session(self, handle: str) -> None:
        """Tear down the persistent shell for ``handle`` (idempotent)."""
        with self._lock:
            shell = self._shells.pop(handle, None)
        if shell is not None:
            shell.close()

    def detach_shell(self, handle: str) -> None:
        """Fence a persistent shell before AgentENV persists the sandbox.

        ``_AgentShell`` has no permanent event stream between execs, so this
        only prevents new commands from attaching while pause is in flight.
        """
        with self._lock:
            shell = self._shells.get(handle)
        if shell is not None:
            shell.detach_for_hibernate()

    def restore_shell_after_failed_hibernate(self, handle: str) -> None:
        """Undo the exec fence when AgentENV rejected the pause request."""
        with self._lock:
            shell = self._shells.get(handle)
        if shell is not None:
            shell.restore_after_failed_hibernate()

    def reconnect_shell(self, handle: str, *, timeout: float = 30.0) -> None:
        """Reconnect a previously-live bash through a fresh Sandbox client."""
        with self._lock:
            shell = self._shells.get(handle)
        if shell is None:
            return
        sbx = shell.reconnect(lambda: self._connect(handle), timeout=timeout)
        if sbx is not None:
            with self._lock:
                self._attached[handle] = sbx

    def execute_full(
        self, handle: str, argv: str | list[str], timeout_ms: int
    ) -> tuple[int, str]:
        """Run ``argv`` in the sandbox's **persistent shell**.

        The sbench :class:`~scheduler.backends.replay.Provider` adapter
        measures wall time itself (around this call) for cross-provider
        fairness and needs stdout to populate the §4 record. Unlike the
        legacy one-shot ``commands.run`` path (which spawned a fresh
        ``sh -c`` per call and lost ``cd``/``export`` across a lane), this
        feeds the recorded script to a single long-running bash -- the
        stateful-replay contract in docs/benchmarks/sbench.md §7, and the
        same shape flash-sandbox's ``POST /sandboxes/{id}/shell`` serves.

        Scripts run directly in the persistent bash; argv is shell-quoted
        literally, including explicit shell invocations. A non-zero exit is a
        normal application outcome (recorded commands often grep for missing
        files or run failing tests) and is returned,
        never raised. A process-stream deadline raises even after guest
        process-tree cleanup is confirmed: cleanup is not an application
        result. A shell-reported exit 124 remains a normal application outcome.
        """
        script = argv if isinstance(argv, str) else shlex.join(argv)
        secs = max(1, timeout_ms // 1000)
        return self._shell_for(handle, timeout_ms=timeout_ms).run(
            script, timeout_s=float(secs)
        )

    def release_session(self, handle: str) -> None:
        self.close_session(handle)
        with self._lock:
            self._attached.pop(handle, None)

    def close(self) -> None:
        with self._lock:
            handles = list(self._attached)
        for handle in handles:
            self.release_session(handle)

    def destroy(self, handle: str) -> None:
        self.release_session(handle)
        try:
            http(f"{self.base}/sandboxes/{handle}", "DELETE", None, self.headers)
        except urllib.error.HTTPError:
            pass
