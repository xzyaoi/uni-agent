"""Shared persistent shell baseline client implementation."""

from __future__ import annotations

import json
import logging
import shlex
import threading
import time
import uuid
from typing import Any

_AGENT_TIMEOUT_CLEANUP = r"""
import collections, json, os, signal, sys, time
root, expected, token = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
deadline = time.monotonic() + 25
# Python 3.5 dicts do not preserve discovery order. Reverse discovery kills
# descendants before their frozen parents on every supported guest version.
owned = collections.OrderedDict()

def stat(pid):
    try:
        with open('/proc/%d/stat' % pid) as f:
            fields = f.read().rsplit(')', 1)[1].split()
        return fields[0], int(fields[19])
    except (FileNotFoundError, ProcessLookupError):
        return None

def check_time():
    if time.monotonic() >= deadline:
        raise RuntimeError('process cleanup deadline exceeded')

def matching(pid, start):
    current = stat(pid)
    return current if current is not None and current[1] == start else None

def kill_owned():
    for pid, start in reversed(list(owned.items())):
        if matching(pid, start):
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass

try:
    current = matching(root, expected)
    if root <= 1 or root == os.getpid() or current is None or current[0] in 'ZX':
        raise RuntimeError('session identity unavailable before cleanup')
    owned[root] = expected
    queue = [root]
    for pid in queue:
        check_time()
        current = matching(pid, owned[pid])
        if current is None or current[0] in 'ZX':
            raise RuntimeError('descendant exited before ownership walk')
        os.kill(pid, signal.SIGSTOP)
        # Every task must be stopped before reading children: the leader can
        # stop while another thread is still forking or in uninterruptible IO.
        while True:
            check_time()
            if matching(pid, owned[pid]) is None:
                raise RuntimeError('process identity changed during freeze')
            tasks = os.listdir('/proc/%d/task' % pid)
            states = []
            for tid in tasks:
                with open('/proc/%d/task/%s/stat' % (pid, tid)) as f:
                    states.append(f.read().rsplit(')', 1)[1].split()[0])
            if states and all(s in 'Tt' for s in states):
                break
            time.sleep(.01)
        for tid in tasks:
            with open('/proc/%d/task/%s/children' % (pid, tid)) as f:
                children = [int(child) for child in f.read().split()]
            for child in children:
                if child in owned:
                    continue
                current = stat(child)
                if current is None or current[0] in 'ZX':
                    raise RuntimeError('child identity unavailable during walk')
                owned[child] = current[1]
                queue.append(child)
    kill_owned()
    while any(s is not None and s[0] not in 'ZX'
              for s in (matching(pid, start) for pid, start in owned.items())):
        check_time()
        time.sleep(.01)
    print(json.dumps({'token': token, 'terminated': True}))
finally:
    # A failed walk must not leave discovered processes frozen. Failure still
    # propagates; killing the known subset is not proof of complete cleanup.
    kill_owned()
"""


def _agent_execution_deadline(error: Exception | None) -> bool:
    """Recognize the SDK's typed process-stream deadline, not HTTP timeouts."""
    try:
        from e2b_connect.client import Code, ConnectException
    except ImportError:
        return False
    seen = set()
    while error is not None and id(error) not in seen:
        seen.add(id(error))
        if isinstance(error, ConnectException):
            return error.status == Code.deadline_exceeded
        error = error.__cause__ or error.__context__
    return False


class _AgentShell:
    """One persistent ``bash --norc --noprofile`` session over the E2B SDK.

    This is the AgentENV analogue of flash-sandbox's in-sandbox persistent
    shell (``sandbox-core/internal/pebble/docker/shell.go``): a single
    long-running bash whose ``cd``/``export``/``source`` state survives
    across the execs of one lane -- the stateful-replay contract in
    docs/benchmarks/sbench.md §7. A provider that runs each exec as a
    fresh process (the default ``commands.run`` path) does NOT satisfy it
    and is only a lower-bound/diagnostic comparison.

    Mechanism: envd's ``commands.run`` always wraps the command in
    ``/bin/bash -l -c <cmd>``; we pass ``"exec bash --norc --noprofile"``
    so the persistent bash REPLACES that wrapper (same PID, inheriting the
    stdin pipe envd set up because ``stdin=True``). Each recorded command
    is then fed to that bash via ``send_stdin`` with a per-call sentinel
    (``<sentinel>_EXIT_<rc>`` printed on stdout) to delimit one call's
    output from the next and capture its exit code. The bash never exits
    until :meth:`close` SIGKILLs it.

    The host does not keep an E2B event stream open between commands. Start
    obtains the bash PID and immediately disconnects; each :meth:`run`
    reconnects to that PID, sends one sentinel-delimited command, consumes
    output in the caller thread, and disconnects again. This is important for
    persisted pause: AgentENV restores the bash process but not a host gRPC
    stream. Per-command attachment preserves shell state while making resume
    a simple swap to a fresh Sandbox client.
    """

    def __init__(self, sbx: Any) -> None:
        self._sbx = sbx
        self._control_handle: Any = None
        self._pid: int = 0
        self._alive: bool = False
        self._alive_before_hibernate: bool | None = None
        self._root_starttime: int | None = None
        self._timeout_cleanup_confirmed = False
        self._lock = threading.Lock()

    def _send_stdin(self, handle: Any, data: str, *, request_timeout: float) -> None:
        """Write to the persistent process across E2B SDK API versions."""
        send = getattr(handle, "send_stdin", None)
        if callable(send):
            send(data, request_timeout=request_timeout)
            return
        # E2B SDK 2.20 moved stdin delivery from CommandHandle to Commands.
        self._sbx.commands.send_stdin(
            self._pid,
            data,
            request_timeout=request_timeout,
        )

    def start(self, *, timeout: float = 30.0) -> None:
        handle = self._sbx.commands.run(
            "exec bash --norc --noprofile",
            background=True,
            stdin=True,
            timeout=0,
        )
        self._pid = getattr(handle, "pid", 0)
        if not self._pid:
            raise RuntimeError("agentenv persistent shell returned no process id")
        self._control_handle = handle
        self._alive = True
        # Capture before any user command can exit/reparent this process.
        # Older/non-AgentENV adapters can still run, but cannot certify a
        # timeout without the guest file API and a stable process identity.
        try:
            value = self._sbx.files.read(
                f"/proc/{self._pid}/stat", user="root", request_timeout=20
            )
            self._root_starttime = int(value.rsplit(")", 1)[1].split()[19])
        except Exception:  # noqa: BLE001 - optional external SDK capability probe
            self._root_starttime = None
        disconnect = getattr(handle, "disconnect", None)
        if callable(disconnect):
            disconnect()

    def detach_for_hibernate(self) -> None:
        """Fence execs while AgentENV persists the already-detached process."""
        with self._lock:
            if self._alive_before_hibernate is None:
                self._alive_before_hibernate = self._alive
            self._alive = False

    def restore_after_failed_hibernate(self) -> None:
        """Make the still-running process usable when the pause API fails."""
        with self._lock:
            if self._alive_before_hibernate is not None:
                self._alive = self._alive_before_hibernate
                self._alive_before_hibernate = None

    def reconnect(self, connect_sandbox: Any, *, timeout: float) -> Any:
        """Attach a fresh client to the restored bash PID, retrying readiness."""
        with self._lock:
            if self._alive_before_hibernate is False:
                self._alive_before_hibernate = None
                return None
        deadline = time.monotonic() + max(timeout, 0.001)
        last_exc: Exception | None = None
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                detail = f": {last_exc}" if last_exc is not None else ""
                raise RuntimeError(
                    f"agentenv persistent shell reconnect timed out after {timeout:.1f}s{detail}"
                )
            try:
                sbx = connect_sandbox()
                handle = self._connect_process(sbx, timeout=0, remaining=remaining)
                disconnect = getattr(handle, "disconnect", None)
                if callable(disconnect):
                    disconnect()
                with self._lock:
                    self._sbx = sbx
                    self._control_handle = handle
                    self._alive = True
                    self._alive_before_hibernate = None
                return sbx
            except Exception as exc:  # noqa: BLE001 - retry pre-dispatch SDK connection only
                last_exc = exc
                time.sleep(min(0.1, max(0.0, remaining)))

    def _connect_process(self, sbx: Any, *, timeout: float, remaining: float) -> Any:
        try:
            return sbx.commands.connect(
                self._pid,
                timeout=timeout,
                request_timeout=max(1.0, min(remaining, 900.0)),
            )
        except TypeError:
            return sbx.commands.connect(self._pid, timeout=timeout)

    def run(self, script: str, *, timeout_s: float) -> tuple[int, str]:
        with self._lock:
            if not self._alive:
                raise RuntimeError("agentenv persistent shell is dead")
            stream_timeout = max(timeout_s, 1.0)
            handle = self._connect_process(
                self._sbx,
                timeout=stream_timeout,
                remaining=stream_timeout + 5.0,
            )
            self._control_handle = handle
            sentinel = f"__SBENCH_{uuid.uuid4().hex[:8]}__"
            wrapper = (
                # Parse only the recorded script inside eval: unmatched quotes
                # must not consume the completion marker or the next request.
                f"builtin eval -- {shlex.quote(script)} </dev/null\n"
                f"__sb_rc=$?\n"
                f"printf '%s_EXIT_%s\\n' '{sentinel}' \"$__sb_rc\"\n"
            )
            joined = ""
            failure: Exception | None = None
            submitted = False
            try:
                self._send_stdin(
                    handle,
                    wrapper,
                    request_timeout=max(timeout_s, 1.0) + 5.0,
                )
                submitted = True
                exit_prefix = f"{sentinel}_EXIT_"
                for stdout, _stderr, _pty in handle:
                    if stdout is None:
                        continue
                    joined += stdout
                    idx = joined.rfind(exit_prefix)
                    if idx < 0:
                        continue
                    after = joined[idx + len(exit_prefix) :]
                    nl = after.find("\n")
                    if nl < 0:
                        continue
                    try:
                        rc = int(after[:nl].strip())
                    except ValueError:
                        rc = 0
                    return rc, joined[:idx]
            except Exception as exc:  # noqa: BLE001 - every post-dispatch failure is uncertain
                failure = exc
            finally:
                disconnect = getattr(handle, "disconnect", None)
                if callable(disconnect):
                    disconnect()
            self._alive = False
            if (
                submitted
                and _agent_execution_deadline(failure)
                and self._root_starttime is not None
            ):
                token = uuid.uuid4().hex
                try:
                    result = self._sbx.commands.run(
                        shlex.join(
                            [
                                "python3",
                                "-c",
                                _AGENT_TIMEOUT_CLEANUP,
                                str(self._pid),
                                str(self._root_starttime),
                                token,
                            ]
                        ),
                        user="root",
                        timeout=30,
                        request_timeout=35,
                    )
                    if result.exit_code != 0:
                        raise RuntimeError(
                            f"guest timeout cleanup exited {result.exit_code}: {result.stderr[:1024]}"
                        )
                    proof = json.loads(result.stdout)
                    if proof != {"token": token, "terminated": True}:
                        raise RuntimeError(
                            "guest timeout cleanup returned invalid proof"
                        )
                except Exception as cleanup_error:  # noqa: BLE001 - require positive cleanup proof
                    raise RuntimeError(
                        f"agentenv timeout cleanup unconfirmed: {cleanup_error}"
                    ) from failure
                self._timeout_cleanup_confirmed = True
                # Cleanup establishes termination, not an application result.
                # Preserve the deadline exception channel so callers cannot
                # mistake a manufactured 124 for a shell-reported exit code.
                raise TimeoutError(
                    "agentenv execution deadline exceeded; guest process cleanup confirmed"
                ) from failure
            try:
                handle.kill()
            except Exception:
                logging.getLogger(__name__).warning("Failed to kill persistent shell", exc_info=True)
            # The SDK's kill acknowledges a signal, not termination of every
            # descendant. An exhausted stream deadline therefore remains an
            # infrastructure failure; never manufacture application exit 124.
            if failure is not None:
                raise failure
            raise TimeoutError(
                f"agentenv persistent shell: command timed out after {timeout_s}s"
            )

    def close(self) -> None:
        with self._lock:
            self._alive = False
            handle = self._control_handle
        if handle is not None:
            try:
                handle.kill()
            except Exception:
                logging.getLogger(__name__).warning("Failed to kill persistent shell", exc_info=True)
