"""Importable baseline transports shared by providers and benchmark commands."""
