"""Shared common baseline client implementation."""

from __future__ import annotations

import json
import urllib.error
import urllib.request
import uuid
from typing import Any


class Target:
    """One system under test. Subclasses implement the three lifecycle ops."""

    name = "?"

    def create(self, lane: dict) -> str: ...
    def prepare(self, handle: str) -> None: ...
    def execute(self, handle: str, argv: str | list[str], timeout_ms: int) -> int: ...
    def destroy(self, handle: str) -> None: ...

    def pause(self, handle: str) -> None:
        raise NotImplementedError(f"{self.name} does not implement pause-in-place")

    def resume(self, handle: str) -> None:
        raise NotImplementedError(f"{self.name} does not implement resume-in-place")

    def hibernate(self, handle: str) -> None:
        raise NotImplementedError(f"{self.name} does not implement hibernate")

    def restore(self, handle: str) -> None:
        raise NotImplementedError(f"{self.name} does not implement hibernate restore")

    # -- Two always-on experiment invariants (not opt-in) ------------------
    #
    # 1. STATEFUL exec. Every command is driven through ONE persistent shell
    #    per sandbox (FlashTarget -> /sandboxes/{id}/shell; K8s -> one
    #    `kubectl exec -i` bash; AgentENV -> one envd shell; Dirigent bypass
    #    -> one flash-envd session) so cd/export/source survive across the
    #    lane's execs. verify_stateful() PROVES that at run time: it exports
    #    an env var in one exec and asserts it back in the next. run_lane
    #    calls it once after the lane and flags the lane not-ok on a
    #    mismatch -- a silent drop to one-shot exec would void the
    #    head-to-head. The only arm that is one-shot by design is Dirigent
    #    real-invoke (each userfn request is a fresh process); it overrides
    #    expects_stateful() to False and returns a documented verdict.
    #
    # 2. FIRECRACKER. Only the flash arm is required to run on Firecracker
    #    (the baselines are not). verify_firecracker() is a no-op for
    #    non-flash arms; FlashTarget overrides it to GET /status and confirm
    #    an available firecracker node before any lane runs.

    def verify_stateful(self, handle: str) -> tuple[bool, str | None]:
        """Prove self.execute preserves shell env across calls (base impl)."""
        return verify_stateful_probe(self, handle)

    def expects_stateful(self) -> bool:
        """Whether verify_stateful() is expected to pass (base: always)."""
        return True

    def verify_firecracker(self) -> None:
        """No-op for non-flash arms; FlashTarget overrides it."""
        return


def verify_stateful_probe(target: Target, handle: str) -> tuple[bool, str | None]:
    """Generic statefulness check via self.execute exit codes.

    Two execs against the SAME handle:
      set:   "export <TOKEN>=1"
      check: '[ "$<TOKEN>" = 1 ] || exit 7'

    A stateful shell runs both in one long-lived bash, so $TOKEN is 1 and
    check exits 0. A stateless shell (fresh process per call) leaves TOKEN
    unset, so check exits 7. TOKEN is randomized so it cannot collide with a
    var the workload itself sets. We test the exit CODE (not stdout) because
    every transport here wraps each command in a brace group in the ONE
    persistent bash (Flash /shell, flash-envd /sessions/{id}/exec, kubectl
    exec) -- a subshell (`sh -lc`) would lose the export and defeat the test.
    """
    token = f"FSB_SV_{uuid.uuid4().hex[:8]}"
    try:
        set_rc = target.execute(
            handle, f"export {token}=1", timeout_ms=15000
        )
        check_rc = target.execute(
            handle, f'[ "${token}" = 1 ] || exit 7', timeout_ms=15000
        )
    except Exception as e:  # noqa: BLE001 - provider errors become probe evidence
        return False, f"probe raised {type(e).__name__}: {e}"
    if not isinstance(set_rc, int) or not isinstance(check_rc, int):
        return False, (
            f"probe returned non-int codes set={set_rc!r} check={check_rc!r}"
        )
    if set_rc != 0:
        return False, f"set exec exit {set_rc} (expected 0)"
    if check_rc == 0:
        return True, None
    return False, (f"check exec exit {check_rc} (7 = state lost across execs)")


def http(
    url: str,
    method: str,
    body: Any = None,
    headers: dict | None = None,
    timeout: float = 900,
) -> tuple[int, Any]:
    data = json.dumps(body).encode() if body is not None else None
    hdrs = {"Content-Type": "application/json"}
    hdrs.update(headers or {})
    req = urllib.request.Request(url, data=data, method=method, headers=hdrs)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()
        parsed = None
        if raw:
            try:
                parsed = json.loads(raw)
            except (json.JSONDecodeError, UnicodeDecodeError):
                parsed = raw[:400]
        return r.status, parsed
