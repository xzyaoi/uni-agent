# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from .base import BaseEngine, EngineRegistry
from .fsdp import FSDPEngine, FSDPEngineWithLMHead

__all__ = [
    "BaseEngine",
    "EngineRegistry",
    "FSDPEngine",
    "FSDPEngineWithLMHead",
]

try:
    from .torchtitan import TorchTitanEngine, TorchTitanEngineWithLMHead

    __all__ += ["TorchTitanEngine", "TorchTitanEngineWithLMHead"]
except ImportError:
    TorchTitanEngine = None
    TorchTitanEngineWithLMHead = None

try:
    from .veomni import VeOmniEngine, VeOmniEngineWithLMHead

    __all__ += ["VeOmniEngine", "VeOmniEngineWithLMHead"]
except ImportError:
    VeOmniEngine = None
    VeOmniEngineWithLMHead = None

try:
    from .automodel import AutomodelEngine, AutomodelEngineWithLMHead

    __all__ += ["AutomodelEngine", "AutomodelEngineWithLMHead"]
except ImportError:
    AutomodelEngine = None
    AutomodelEngineWithLMHead = None

# Mindspeed must be imported before Megatron to ensure the related monkey patches take effect as expected
try:
    from .mindspeed import MindspeedEngineWithLMHead, MindspeedEngineWithValueHead, MindSpeedMegatronEngineWithLMHead

    __all__ += ["MindspeedEngineWithLMHead", "MindspeedEngineWithValueHead", "MindSpeedMegatronEngineWithLMHead"]
except ImportError:
    MindspeedEngineWithLMHead = None
    MindspeedEngineWithValueHead = None
    MindSpeedMegatronEngineWithLMHead = None

try:
    from .megatron import MegatronEngine, MegatronEngineWithLMHead, MegatronEngineWithValueHead

    __all__ += ["MegatronEngine", "MegatronEngineWithLMHead", "MegatronEngineWithValueHead"]
except ImportError:
    MegatronEngine = None
    MegatronEngineWithLMHead = None
