"""ReAct: the white-box agent driven by our own framework loop (reason + tool-call act)."""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING, Any

from pydantic import Field

from uni_agent.sandbox.exec_context import bind_exec_metadata, current_exec_metadata
from uni_agent.tools import Toolbox

from ..base import Agent, AgentConfig, AgentResult
from ..registry import register_agent
from .model import OpenAICompatibleChatModel

if TYPE_CHECKING:
    from uni_agent.sandbox import Sandbox

logger = logging.getLogger(__name__)

#: Tool names that end the episode when the policy calls them.
_FINISH_TOOLS = {"submit", "finish"}

#: Max chars of LLM ``content`` / tool ``arguments`` retained in exec metadata
#: (the rest is truncated) so the sandbox exec trace + structured event log
#: stays manageable. Override with the env var of the same name.
_LLM_PREVIEW_CHARS = int(os.getenv("FLASH_SANDBOX_LLM_PREVIEW_CHARS", "2048"))
#: Per-message cap for the full-fidelity ``llm.messages_delta`` bag forwarded
#: to flash-sandbox (env-tunable; 0 disables capping). Deltas replay to the
#: exact conversation, but a single tool observation (e.g. a full test-suite
#: log) can be hundreds of KB -- cap each field so exec-request bodies stay
#: well under any relay body limit. The uncapped conversation remains in the
#: local trajectory.json.
_LLM_DELTA_CHARS = int(os.getenv("FLASH_SANDBOX_LLM_DELTA_CHARS", "65536"))


def _cap_messages(messages: list[dict[str, Any]], limit: int = _LLM_DELTA_CHARS) -> list[dict[str, Any]]:
    """Cap each message's string fields for the exec metadata delta.

    ``llm.messages_delta`` rides inside the flash-sandbox metadata bag, so
    unbounded contents could inflate exec-request bodies; each string field is
    truncated independently (marked, consistent with :func:`_truncate`). The
    uncapped conversation always remains in the local trajectory.json.
    """
    if limit <= 0:
        return messages
    capped: list[dict[str, Any]] = []
    for m in messages:
        c = dict(m)
        if isinstance(c.get("content"), str):
            c["content"] = _truncate(c["content"], limit)
        if isinstance(c.get("reasoning_content"), str):
            c["reasoning_content"] = _truncate(c["reasoning_content"], limit)
        capped.append(c)
    return capped


def _truncate(value: Any, limit: int = _LLM_PREVIEW_CHARS) -> Any:
    """Truncate a string ``value`` to ``limit`` chars (appending ``…``).

    Non-strings pass through unchanged so the metadata stays JSON-safe and the
    helper is usable for both LLM ``content`` and tool ``arguments``.
    """
    if not isinstance(value, str) or limit <= 0 or len(value) <= limit:
        return value
    return value[:limit] + "…"


class ReActConfig(AgentConfig):
    """White-box launch params: host-side tools + step / timeout budgets."""

    name: str = "react"
    tools: list[dict] = Field(
        default_factory=lambda: [
            {"name": "str_replace_editor"},
            {"name": "stateful_shell", "command_timeout": 120},
            {"name": "submit"},
        ],
        description="Host-side tools exposed to the policy (each a {name, ...kwargs} entry). "
        "Include a finish tool (submit/finish) so the policy can end the episode explicitly.",
    )
    max_steps: int = Field(default=50, description="Max tool-calling turns per episode.")
    action_timeout: float | None = Field(
        default=None,
        description="Per-call timeout (s) forwarded to each tool call, overriding the tool's own "
        "default (e.g. the shell's command_timeout); None defers to the tool's own timeout.",
    )
    timeout_budget: int = Field(
        default=3,
        description="Tool-call timeouts tolerated per episode before it stops with a timeout-limit reason.",
    )


@register_agent("react")
class ReActAgent(Agent):
    """White-box solver: framework loop + host-side tools over an OpenAI endpoint."""

    config_model = ReActConfig

    async def run(
        self,
        *,
        sandbox: Sandbox,
        messages: list[dict[str, Any]],
    ) -> AgentResult:
        cfg: ReActConfig = self.config  # type: ignore[assignment]
        if cfg.model.base_url is None:
            raise ValueError("react: config.model.base_url is not set (the endpoint the policy calls)")

        toolbox = Toolbox.from_specs(cfg.tools, sandbox=sandbox)
        model = OpenAICompatibleChatModel(
            base_url=cfg.model.base_url,
            api_key=cfg.model.api_key,
            model_name=cfg.model.model_name,
            sampling_params=cfg.model.sampling_params(),
            tools_schemas=toolbox.schemas(),
        )

        transcript: list[dict[str, Any]] = list(messages)
        for message in messages:
            logger.info(f"{str(message.get('role', '')).upper()} PROMPT:\n{message.get('content', '')}")
        trajectory_info: dict[str, Any] = {
            "steps": 0,
            "num_tool_calls": 0,
            "timeouts": 0,
            "errors": 0,
            "total_tokens": 0,
            # Transcript watermark for the flash-sandbox llm.messages_delta
            # capture: index up to which messages have already been snapshotted
            # into an exec metadata delta (persisted across step() calls).
            "meta_watermark": 0,
        }
        # Align the delta watermark with what the flash-sandbox backend
        # already holds: the session base bound by the framework around this
        # run ships ``llm.initial_messages`` == the raw_prompt seed of the
        # transcript, so advancing the watermark past the seed avoids
        # re-sending it in the first exec delta. On any mismatch (string
        # prompt, capped initial_messages) the watermark stays 0 and the seed
        # rides in the first delta instead -- capture stays complete either way.
        _base_llm = current_exec_metadata().get("llm") or {}
        _init = _base_llm.get("initial_messages") or []
        if _init and len(_init) <= len(transcript) and transcript[: len(_init)] == _init:
            trajectory_info["meta_watermark"] = len(_init)
        termination_reason = "unknown"
        try:
            async with toolbox.entered(
                    retry=int(os.getenv("SANDBOX_START_RETRIES", "3")),
                    timeout=float(os.getenv("SANDBOX_START_ATTEMPT_TIMEOUT", "60")),
                ):
                for step_idx in range(1, cfg.max_steps + 1):
                    trajectory_info["steps"] = step_idx
                    stop_reason = await self.step(cfg, model, toolbox, transcript, trajectory_info)
                    if stop_reason != "completed":
                        termination_reason = stop_reason
                        break
                else:  # loop ran the full step budget without an early stop
                    termination_reason = "max_steps"
                    logger.warning(f"Reached max steps ({cfg.max_steps}) without finishing.")
        except Exception as exc:  # keep the partial transcript; the task buckets the failure
            logger.exception("react loop failed at step %s", trajectory_info["steps"])
            termination_reason = "unknown_error"
            trajectory_info["error"] = f"{type(exc).__name__}: {exc}"
        finally:
            await model.aclose()  # release the reused HTTP session

        logger.info(
            f"Episode done: termination_reason={termination_reason} steps={trajectory_info['steps']} "
            f"tool_calls={trajectory_info['num_tool_calls']} timeouts={trajectory_info['timeouts']} "
            f"errors={trajectory_info['errors']} total_tokens={trajectory_info['total_tokens']}"
        )
        return AgentResult(transcript=transcript, info=trajectory_info, finished=termination_reason == "finished")

    async def step(
        self,
        cfg: ReActConfig,
        model: OpenAICompatibleChatModel,
        toolbox: Toolbox,
        transcript: list[dict[str, Any]],
        info: dict[str, Any],
    ) -> str:
        """Run one turn: query the policy, record its message, run its tool calls."""
        logger.info(f"{'=' * 25} STEP {info['steps']} {'=' * 25}")

        # step 1: query the model
        max_tokens = cfg.model.max_tokens_per_turn or cfg.model.max_total_tokens
        if cfg.model.max_total_tokens is not None:
            remaining = cfg.model.max_total_tokens - info["total_tokens"]
            if remaining <= 0:
                logger.info(f"Exit: token budget spent ({info['total_tokens']}/{cfg.model.max_total_tokens}).")
                return "token_limit"
            max_tokens = min(max_tokens, remaining)

        sampling_params: dict[str, Any] = cfg.model.sampling_params()
        if max_tokens is not None:  # both budgets unset -> let the server run to EOS
            sampling_params["max_tokens"] = max_tokens
        content, tool_calls, gen_info = await model.query(transcript, sampling_params=sampling_params)
        info["total_tokens"] = gen_info["prompt_tokens"] + gen_info["completion_tokens"]
        finish_reason = gen_info.get("finish_reason")
        logger.info(
            f"Prompt Tokens: {gen_info['prompt_tokens']}, Completion Tokens: {gen_info['completion_tokens']} "
            f"(total {info['total_tokens']})"
        )
        logger.info(f"💭 THOUGHT:\n{content}")

        assistant_msg: dict[str, Any] = {"role": "assistant", "content": content}
        if tool_calls:
            assistant_msg["tool_calls"] = tool_calls
        transcript.append(assistant_msg)
        # Thinking tokens for the metadata capture: when the serving stack
        # separates reasoning (vLLM --reasoning-parser) it arrives in
        # ``reasoning_content`` instead of inline in ``content``. Keep it out
        # of the transcript (the chat template owns reasoning replay) but in
        # the exec metadata so flash-sandbox captures the actual LLM output.
        assistant_delta: dict[str, Any] = dict(assistant_msg)
        reasoning = gen_info.get("reasoning_content")

        if cfg.model.max_total_tokens is not None and info["total_tokens"] >= cfg.model.max_total_tokens:
            logger.info(f"Exit: token budget reached ({info['total_tokens']}/{cfg.model.max_total_tokens}).")
            return "token_limit"

        if finish_reason == "length":
            logger.info("Exit: response truncated at a token cap.")
            return "token_limit"

        if not tool_calls:
            logger.info("💬 FINISHED: policy replied with plain text (no tool call).")
            return "finished"

        # Capture this turn's LLM input/output (token counts + truncated content
        # and tool calls) so a downstream consumer of the sandbox exec trace +
        # structured event log can reconstruct the full execution pattern: which
        # LLM turn, in which group/trajectory, produced which sandbox command.
        _llm_meta = {
            # Which LLM produced this turn: the resolved request model id
            # (generation_info), falling back to the endpoint attribute.
            "model": gen_info.get("model") or getattr(model, "model_name", None),
            "prompt_tokens": int(gen_info.get("prompt_tokens") or 0),
            "completion_tokens": int(gen_info.get("completion_tokens") or 0),
            "total_tokens": int(info["total_tokens"]),
            "finish_reason": gen_info.get("finish_reason"),
            "content": _truncate(content),
            "tool_calls": [
                {
                    "name": tc.get("function", {}).get("name"),
                    "arguments": _truncate(tc.get("function", {}).get("arguments")),
                }
                for tc in tool_calls
            ],
            "step": int(info.get("steps") or 0),
        }

        # step 2: dispatch the tool calls
        saw_finish = False
        for idx, tool_call in enumerate(tool_calls):
            fn = tool_call.get("function", {})
            name = fn.get("name", "")
            logger.info(f"🎬 ACTION ({name}):\n{fn.get('arguments')}")
            # Tag this exec with the LLM input/output that produced it. The
            # session-level rlvr group/rollout base is already bound by the
            # framework (or re-bound in a Ray worker), so this overlay adds the
            # per-call ``llm`` bag the provider forwards onto the exec trace +
            # structured event log.
            # Input-side capture: snapshot the transcript slice appended since
            # the previous exec (running watermark) and advance the watermark
            # BEFORE the exec, so this exec's own observation lands in the
            # NEXT exec's delta. Replaying ``llm.initial_messages`` (session
            # base, set by the framework) plus every ``llm.messages_delta`` in
            # exec order reconstructs the exact full conversation -- system +
            # user prompt, thinking tokens, and every tool observation.
            wm = int(info.get("meta_watermark") or 0)
            delta = transcript[wm:]
            if reasoning and delta and delta[-1] is assistant_msg:
                delta = delta[:-1] + [assistant_delta]
            info["meta_watermark"] = len(transcript)
            async with bind_exec_metadata(
                llm={
                    **_llm_meta,
                    "tool_name": name,
                    "tool_arguments": _truncate(fn.get("arguments")),
                    "messages_delta": _cap_messages(delta),
                },
            ):
                tool_result = await toolbox.call(name, fn.get("arguments"), timeout=cfg.action_timeout)
            observation = tool_result.to_observation()
            info["num_tool_calls"] += 1
            if tool_result.status == "timeout":  # a tool hit its own timeout (e.g. shell command_timeout)
                info["timeouts"] += 1
                logger.warning(
                    f"⏳ TIMEOUT ({name}): {info['timeouts']}/{cfg.timeout_budget} budget used\n{observation}"
                )
            elif tool_result.status != "ok":
                info["errors"] += 1
                logger.warning(f"❌ TOOL {tool_result.status.upper()} ({name}):\n{observation}")
            else:
                logger.info(f"👀 OBSERVATION ({name}):\n{observation}")

            transcript.append(
                {
                    "role": "tool",
                    "tool_call_id": tool_call.get("id"),
                    "name": name,
                    "content": observation,
                }
            )

            if info["timeouts"] > cfg.timeout_budget:
                logger.warning("Exit: timeout budget exhausted; skipping remaining tool calls this turn.")
                for tool_call in tool_calls[idx + 1 :]:
                    transcript.append(
                        {
                            "role": "tool",
                            "tool_call_id": tool_call.get("id"),
                            "name": tool_call.get("function", {}).get("name", ""),
                            "content": "Skipped: timeout budget exhausted.",
                        }
                    )
                return "timeout_limit"
            if name in _FINISH_TOOLS and tool_result.status == "ok":
                saw_finish = True
        if saw_finish:
            logger.info("💬 FINISHED: policy called a finish tool.")
        return "finished" if saw_finish else "completed"
