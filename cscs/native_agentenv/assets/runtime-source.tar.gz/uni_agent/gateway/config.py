"""Public config dataclass for GatewayActor wiring.

Carries model, codec, and session knobs that entry.py forwards to the
gateway actor. The backend client is injected separately by GatewayManager;
only its rollout name is forwarded here to select a matching tool parser.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class GatewayActorConfig:
    """Model and session configuration forwarded into each gateway actor.

    Attributes:
        tokenizer: Tokenizer used by the message codec.
        processor: Optional multimodal processor used for vision requests.
        tool_parser_name: Optional tool parser name for decoding tool calls.
        rollout_backend: Inference backend name used to select the matching
            SGLang or vLLM parser. Other backends use verl's parser registry.
        apply_chat_template_kwargs: Default kwargs passed to chat-template rendering.
        allowed_request_sampling_param_keys: Request sampling keys accepted by the
            provider adapters when merging payload sampling params.
        vision_info_extractor: Optional async extractor for image/video inputs.
        vision_info_extractor_kwargs: Static kwargs forwarded to the extractor.
        prompt_length: Optional prompt component of the total trajectory capacity.
        response_length: Optional response component of the total trajectory capacity.
            The gateway enforces their sum when both values are set.
        enable_last_assistant_rollback: Whether latest-assistant rewrites may
            rollback and reuse an existing chain. Enabled by default.
    """

    tokenizer: Any
    processor: Any | None = None
    tool_parser_name: str | None = None
    rollout_backend: str | None = None
    apply_chat_template_kwargs: dict[str, Any] | None = None
    allowed_request_sampling_param_keys: set[str] | frozenset[str] | None = None
    vision_info_extractor: Callable | None = None
    vision_info_extractor_kwargs: dict[str, Any] | None = None
    prompt_length: int | None = None
    response_length: int | None = None
    enable_last_assistant_rollback: bool = True

    def __post_init__(self) -> None:
        if type(self.enable_last_assistant_rollback) is not bool:
            raise ValueError(
                "enable_last_assistant_rollback must be a bool, "
                f"got {type(self.enable_last_assistant_rollback).__name__}"
            )
        if self.prompt_length is not None and self.prompt_length <= 0:
            raise ValueError(f"prompt_length must be positive when set, got {self.prompt_length}")
        if self.response_length is not None and self.response_length <= 0:
            raise ValueError(f"response_length must be positive when set, got {self.response_length}")
