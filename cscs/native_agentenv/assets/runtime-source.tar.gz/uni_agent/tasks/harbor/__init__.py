"""Harbor CLI task integration."""
